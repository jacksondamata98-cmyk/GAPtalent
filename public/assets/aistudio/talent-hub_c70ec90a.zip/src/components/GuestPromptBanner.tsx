import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, ArrowRight, X, ShieldAlert } from 'lucide-react';
import { TalentIcon } from './TalentIcon';

export const GuestPromptBanner: React.FC = () => {
  const { currentUser, setAuthModalOpen, setAuthModalInitialTab } = useApp();
  const [dismissed, setDismissed] = useState(false);

  // Only show to Guests (CONVIDADO)
  if (currentUser || dismissed) return null;

  return (
    <div className="fixed bottom-24 left-3 right-3 sm:bottom-4 sm:left-auto sm:right-6 sm:max-w-md z-40 bg-gradient-to-r from-stone-900 via-stone-900 to-amber-950/80 border border-amber-500/40 rounded-2xl p-4 shadow-2xl backdrop-blur-xl animate-in slide-in-from-bottom-4 duration-300">
      <button
        onClick={() => setDismissed(true)}
        className="absolute top-2.5 right-2.5 text-stone-400 hover:text-stone-200 p-1 rounded-full"
      >
        <X className="w-4 h-4" />
      </button>

      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
          <TalentIcon size={22} filled />
        </div>

        <div className="space-y-2">
          <div>
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>Está a navegar como Convidado</span>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-mono">
                Modo Leitura
              </span>
            </h4>
            <p className="text-[11px] text-stone-300 leading-snug mt-0.5">
              Para curtir com o ícone de talento, comentar e votar no seu Talent favorito, crie a sua conta gratuita agora!
            </p>
          </div>

          <div className="flex items-center gap-2 pt-0.5">
            <button
              onClick={() => {
                setAuthModalInitialTab('register');
                setAuthModalOpen(true);
              }}
              className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-600 text-stone-950 text-xs font-bold shadow-md shadow-amber-500/20 hover:brightness-110 active:scale-[0.98] transition-all flex items-center gap-1"
            >
              <span>Criar Conta</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => {
                setAuthModalInitialTab('login');
                setAuthModalOpen(true);
              }}
              className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold transition-all"
            >
              Entrar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
