import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Post, Comment } from '../types';
import { CATEGORIES } from '../data/initialData';
import {
  Heart,
  MessageSquare,
  Share2,
  Sparkles,
  Send,
  Clock,
  Radio,
  CheckCircle2,
  AlertCircle,
  Award,
  Crown,
  Play,
  Volume2,
  Megaphone
} from 'lucide-react';
import { TalentIcon } from './TalentIcon';

interface FeedProps {
  onOpenLive: (liveId: string) => void;
  onOpenChallenges: () => void;
}

export const Feed: React.FC<FeedProps> = ({ onOpenLive, onOpenChallenges }) => {
  const {
    posts,
    comments,
    currentUser,
    users,
    lives,
    likePost,
    reactToPost,
    addComment,
    setViewingTalentProfile,
    requestActionOrPromptGuest,
    setActiveLive
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'following' | 'raro' | string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [openCommentsPostId, setOpenCommentsPostId] = useState<string | null>(null);
  const [commentInputs, setCommentInputs] = useState<{ [postId: string]: string }>({});
  const [commentFeedbacks, setCommentFeedbacks] = useState<{ [postId: string]: string }>({});
  const [copiedPostId, setCopiedPostId] = useState<string | null>(null);

  // Filter posts
  const filteredPosts = posts.filter(post => {
    if (activeTab === 'raro') {
      return post.postType === 'raro' || post.isRareContender;
    }
    if (activeTab === 'following') {
      if (!currentUser) return false;
      return currentUser.followingIds.includes(post.authorId);
    }
    if (selectedCategory !== 'all') {
      return post.category === selectedCategory;
    }
    return true;
  });

  const handleCommentSubmit = (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = commentInputs[postId]?.trim();
    if (!text) return;

    const res = addComment(postId, text);
    if (res.success) {
      setCommentInputs(prev => ({ ...prev, [postId]: '' }));
      setCommentFeedbacks(prev => ({ ...prev, [postId]: res.message }));
      setTimeout(() => {
        setCommentFeedbacks(prev => {
          const next = { ...prev };
          delete next[postId];
          return next;
        });
      }, 5000);
    }
  };

  const handleShare = (postId: string) => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedPostId(postId);
    setTimeout(() => setCopiedPostId(null), 2500);
  };

  const getTierIcon = (tier?: string) => {
    if (tier === 'gold') return <span title="1º Talent Gold 🥇">🥇</span>;
    if (tier === 'silver') return <span title="2º Talent Silver 🥈">🥈</span>;
    if (tier === 'bronze') return <span title="3º Talent Bronze 🥉">🥉</span>;
    if (tier === 'top10') return <span className="text-[10px] bg-stone-800 text-amber-400 font-bold px-1.5 py-0.5 rounded">Top 10</span>;
    return null;
  };

  return (
    <div className="space-y-5">
      {/* Active Lives Carousel at Top */}
      {lives.length > 0 && (
        <div className="bg-stone-900/90 border border-red-500/30 rounded-3xl p-4 shadow-xl backdrop-blur-md">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                Transmissões em Directo • Lives Santomenses
              </h3>
            </div>
            <span className="text-[10px] text-stone-400">Ao vivo agora</span>
          </div>

          <div className="flex gap-3 overflow-x-auto pb-1 scrollbar-none">
            {lives.map(live => (
              <div
                key={live.id}
                onClick={() => {
                  setActiveLive(live);
                  onOpenLive(live.id);
                }}
                className="relative flex-shrink-0 w-52 sm:w-64 rounded-2xl overflow-hidden bg-stone-950 border border-stone-800 hover:border-red-500/50 cursor-pointer transition-all group"
              >
                <div className="aspect-video relative overflow-hidden">
                  <img
                    src={live.thumbnailUrl}
                    alt=""
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-80"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-black/20 to-transparent" />
                  <span className="absolute top-2 left-2 bg-red-600 text-white font-black text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                    LIVE
                  </span>
                  <span className="absolute top-2 right-2 bg-black/60 backdrop-blur-md text-stone-200 text-[10px] px-2 py-0.5 rounded-full font-mono">
                    👥 {live.viewerCount}
                  </span>
                  <div className="absolute bottom-2 left-2 right-2 flex items-center gap-2">
                    <img
                      src={live.talentAvatar}
                      alt=""
                      className="w-7 h-7 rounded-full object-cover border border-amber-400"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate drop-shadow">{live.talentName}</p>
                      <p className="text-[10px] text-amber-300 truncate drop-shadow">{live.title}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Feed Filter Tabs */}
      <div className="bg-stone-900/90 border border-stone-800 rounded-2xl p-2 shadow-lg backdrop-blur-md flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1 whitespace-nowrap">
          <button
            onClick={() => {
              setActiveTab('all');
              setSelectedCategory('all');
            }}
            className={`px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
              activeTab === 'all' && selectedCategory === 'all'
                ? 'bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20'
                : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
            }`}
          >
            Todas
          </button>

          <button
            onClick={() => {
              setActiveTab('following');
              setSelectedCategory('all');
            }}
            className={`px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
              activeTab === 'following'
                ? 'bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20'
                : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
            }`}
          >
            A Seguir
          </button>

          <button
            onClick={() => {
              setActiveTab('raro');
              setSelectedCategory('all');
            }}
            className={`px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 ${
              activeTab === 'raro'
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-stone-950 shadow-md shadow-amber-500/20'
                : 'text-yellow-400 hover:text-yellow-300 hover:bg-stone-800 border border-yellow-500/20'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Talent Raro ⭐ (Dia 15)</span>
          </button>
        </div>

        {/* Category Filter Dropdown */}
        <select
          value={selectedCategory}
          onChange={e => {
            setSelectedCategory(e.target.value);
            setActiveTab('category');
          }}
          className="w-full sm:w-auto bg-stone-950 border border-stone-800 text-stone-300 text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-amber-400 shrink-0"
        >
          <option value="all">Todas as Categorias</option>
          {CATEGORIES.map(cat => (
            <option key={cat} value={cat}>
              {cat}
            </option>
          ))}
        </select>
      </div>

      {/* Publications Stream */}
      <div className="space-y-4">
        {filteredPosts.length === 0 ? (
          <div className="p-12 text-center bg-stone-900/60 border border-stone-800 rounded-3xl space-y-3">
            <div className="w-12 h-12 mx-auto rounded-full bg-stone-800 flex items-center justify-center text-stone-500">
              <Sparkles className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-stone-300">Nenhuma publicação encontrada</h4>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              Não há publicações neste filtro no momento. Explore outras categorias ou siga novos criadores!
            </p>
          </div>
        ) : (
          filteredPosts.map(post => {
            const isLiked = currentUser ? post.likedBy.includes(currentUser.id) : false;
            const currentEmoji = currentUser ? post.userReactions?.[currentUser.id] : undefined;
            const postComments = comments.filter(c => c.postId === post.id && c.status === 'approved');
            const myPendingComment = comments.find(
              c => c.postId === post.id && c.status === 'pending' && c.authorId === currentUser?.id
            );
            const isCommentsOpen = openCommentsPostId === post.id;
            const isRare = post.postType === 'raro' || post.isRareContender;

            return (
              <article
                key={post.id}
                className={`bg-stone-900/90 border rounded-2xl sm:rounded-3xl p-3.5 sm:p-5 shadow-xl backdrop-blur-md transition-all ${
                  post.isOfficial
                    ? 'border-amber-400/50 bg-gradient-to-br from-amber-950/20 via-stone-900 to-stone-950'
                    : isRare
                    ? 'border-yellow-500/40'
                    : 'border-stone-800/80 hover:border-stone-700'
                }`}
              >
                {/* Official Announcement / Rare Badge Header */}
                {post.isOfficial && (
                  <div className="mb-3 p-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-600/10 border border-amber-500/30 flex items-center gap-2 text-xs font-bold text-amber-300">
                    <Megaphone className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Comunicado Oficial da Talent Hub • Visível para toda a plataforma</span>
                  </div>
                )}

                {isRare && !post.isOfficial && (
                  <div className="mb-3 px-3 py-1 rounded-xl bg-gradient-to-r from-yellow-500/20 to-amber-500/10 border border-yellow-500/30 inline-flex items-center gap-2 text-xs font-bold text-yellow-300">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Candidato Oficial a TALENT RARO (Votação até dia 15!)</span>
                  </div>
                )}

                {/* Author Info */}
                <div className="flex items-center justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={post.authorAvatar}
                      alt=""
                      onClick={() => {
                        const author = users.find(u => u.id === post.authorId);
                        if (author) setViewingTalentProfile(author);
                      }}
                      className="w-11 h-11 rounded-full object-cover border-2 border-amber-400/60 shadow-md cursor-pointer hover:scale-105 transition-transform"
                    />

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span
                          onClick={() => {
                            const author = users.find(u => u.id === post.authorId);
                            if (author) setViewingTalentProfile(author);
                          }}
                          className="font-bold text-sm text-stone-100 hover:text-amber-400 cursor-pointer transition-colors"
                        >
                          {post.authorName}
                        </span>
                        {getTierIcon(post.authorTier)}
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-stone-400">
                        <span className="text-amber-400 font-medium">@{post.authorUsername}</span>
                        <span>•</span>
                        <span>{post.category}</span>
                      </div>
                    </div>
                  </div>

                  <span className="text-[10px] text-stone-500 flex items-center gap-1 shrink-0">
                    <Clock className="w-3 h-3" />
                    {new Date(post.createdAt).toLocaleDateString('pt-PT', {
                      day: 'numeric',
                      month: 'short'
                    })}
                  </span>
                </div>

                {/* Text Content */}
                <p className="text-stone-200 text-sm leading-relaxed mb-4 whitespace-pre-line">
                  {post.content}
                </p>

                {/* Media (Image or Video) */}
                {post.mediaUrl && post.mediaType === 'image' && (
                  <div className="mb-4 rounded-2xl overflow-hidden border border-stone-800 bg-stone-950 max-h-[500px]">
                    <img
                      src={post.mediaUrl}
                      alt="Conteúdo publicado"
                      className="w-full h-auto max-h-[500px] object-cover hover:scale-[1.01] transition-transform duration-300"
                    />
                  </div>
                )}

                {post.mediaUrl && post.mediaType === 'video' && (
                  <div className="relative mb-4 rounded-2xl overflow-hidden border border-stone-800 bg-stone-950 aspect-video flex items-center justify-center group">
                    <video
                      src={post.mediaUrl}
                      controls
                      className="w-full h-full object-cover"
                      poster="https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1200&q=80"
                    />
                    {post.videoDurationSeconds && (
                      <span className="absolute top-3 right-3 bg-black/70 backdrop-blur-md text-amber-300 text-[10px] font-mono px-2 py-0.5 rounded-full border border-amber-500/30">
                        ⏱️ {Math.floor(post.videoDurationSeconds / 60)}:
                        {(post.videoDurationSeconds % 60).toString().padStart(2, '0')} (máx 2m)
                      </span>
                    )}
                  </div>
                )}

                {/* Interaction Bar */}
                <div className="pt-3 border-t border-stone-800/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
                  <div className="flex items-center justify-between sm:justify-start gap-1.5 sm:gap-2">
                    {/* Like / Curtir with custom TalentIcon */}
                    <button
                      onClick={() => likePost(post.id)}
                      className={`px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl font-bold flex items-center gap-1.5 sm:gap-2 transition-all shrink-0 ${
                        isLiked
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-sm shadow-amber-500/20'
                          : 'bg-stone-950 border border-stone-800 text-stone-400 hover:text-stone-200 hover:border-stone-700'
                      }`}
                      title={currentUser ? 'Curtir e atribuir pontos de talento' : 'Entre para curtir'}
                    >
                      <TalentIcon size={18} filled={isLiked} />
                      <span className="font-mono text-xs">{post.likes.toLocaleString()}</span>
                    </button>

                    {/* Emoji Reactions Picker */}
                    <div className="flex items-center bg-stone-950 border border-stone-800 rounded-xl px-1 py-0.5 sm:px-1.5 sm:py-1 gap-0.5 sm:gap-1">
                      {['🔥', '👏', '💎', '❤️'].map(emoji => {
                        const count = post.reactions?.[emoji] || 0;
                        const isChosen = currentEmoji === emoji;

                        return (
                          <button
                            key={emoji}
                            onClick={() => reactToPost(post.id, emoji)}
                            className={`px-1.5 py-1 rounded-lg text-xs transition-all flex items-center gap-0.5 ${
                              isChosen
                                ? 'bg-amber-500/30 scale-105 border border-amber-400/50'
                                : 'hover:bg-stone-800 opacity-80 hover:opacity-100'
                            }`}
                          >
                            <span>{emoji}</span>
                            {count > 0 && <span className="text-[10px] font-mono text-stone-300">{count}</span>}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-2 pt-1 sm:pt-0 border-t sm:border-t-0 border-stone-800/40">
                    {/* Comments Toggle */}
                    <button
                      onClick={() => setOpenCommentsPostId(isCommentsOpen ? null : post.id)}
                      className={`px-3 py-1.5 sm:py-2 rounded-xl flex items-center gap-1.5 transition-all text-xs ${
                        isCommentsOpen
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-stone-950 border border-stone-800 text-stone-400 hover:text-stone-200'
                      }`}
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>{postComments.length} comentários</span>
                    </button>

                    {/* Share Button */}
                    <button
                      onClick={() => handleShare(post.id)}
                      className="p-1.5 sm:p-2 rounded-xl bg-stone-950 border border-stone-800 text-stone-400 hover:text-stone-200 hover:border-stone-700 transition-all"
                      title="Copiar link da publicação"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {copiedPostId === post.id && (
                  <p className="text-[10px] text-amber-400 mt-2 text-right">
                    Link da publicação copiado para a área de transferência!
                  </p>
                )}

                {/* Comments Section Drawer */}
                {isCommentsOpen && (
                  <div className="mt-4 pt-4 border-t border-stone-800 space-y-3 animate-in fade-in">
                    {/* Notice about admin moderation rule */}
                    <div className="p-2.5 rounded-xl bg-stone-950/90 border border-amber-500/20 text-[11px] text-amber-300/90 flex items-center gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>
                        Regra da Comunidade: Novos comentários são avaliados pelo administrador antes de ficarem visíveis a todos.
                      </span>
                    </div>

                    {/* Pending comment notice if current user submitted */}
                    {myPendingComment && (
                      <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/40 text-xs text-amber-200 flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold">O seu comentário está em avaliação pelo Administrador:</p>
                          <p className="italic mt-0.5 text-stone-300">"{myPendingComment.content}"</p>
                          <p className="text-[10px] text-stone-400 mt-1">
                            A equipa de Atendentes irá validar em breve.
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Approved comments list */}
                    <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                      {postComments.length === 0 && !myPendingComment ? (
                        <p className="text-xs text-stone-500 text-center py-2">
                          Seja o primeiro a comentar esta publicação!
                        </p>
                      ) : (
                        postComments.map(c => (
                          <div
                            key={c.id}
                            className="p-2.5 rounded-xl bg-stone-950 border border-stone-800 flex items-start gap-2.5 text-xs"
                          >
                            <img
                              src={c.authorAvatar}
                              alt=""
                              className="w-7 h-7 rounded-full object-cover border border-amber-500/30 shrink-0 mt-0.5"
                            />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <span className="font-semibold text-stone-200">{c.authorName}</span>
                                <span className="text-[10px] text-stone-500">
                                  {new Date(c.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </div>
                              <p className="text-stone-300 mt-0.5 leading-snug">{c.content}</p>
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Add comment input form */}
                    <form onSubmit={e => handleCommentSubmit(post.id, e)} className="flex gap-2 pt-1">
                      <input
                        type="text"
                        value={commentInputs[post.id] || ''}
                        onChange={e =>
                          setCommentInputs(prev => ({ ...prev, [post.id]: e.target.value }))
                        }
                        placeholder={
                          currentUser ? 'Escreva um comentário público...' : 'Precisa de entrar para comentar...'
                        }
                        className="flex-1 bg-stone-950 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 placeholder:text-stone-600 focus:outline-none focus:border-amber-400"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs transition-colors flex items-center gap-1.5 shrink-0"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Comentar</span>
                      </button>
                    </form>

                    {commentFeedbacks[post.id] && (
                      <p className="text-xs text-emerald-400 animate-in fade-in">
                        {commentFeedbacks[post.id]}
                      </p>
                    )}
                  </div>
                )}
              </article>
            );
          })
        )}
      </div>
    </div>
  );
};
