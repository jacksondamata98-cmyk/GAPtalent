import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  User as UserIcon,
  Camera,
  KeyRound,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  Trophy,
  Calendar,
  MapPin,
  Phone,
  Mail,
  AlertTriangle,
  LogOut,
  LogIn,
  UserPlus,
  RefreshCw,
  PlusCircle,
  Shield
} from 'lucide-react';
import { TalentIcon } from './TalentIcon';

const AVATAR_CHOICES = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1589156280159-27698a70f29e?auto=format&fit=crop&w=400&q=80'
];

interface ProfileViewProps {
  onGoToFeed: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onGoToFeed }) => {
  const {
    currentUser,
    users,
    updateCurrentUserProfile,
    setAuthModalOpen,
    setAuthModalInitialTab,
    setBecomeTalentModalOpen,
    setTalentStudioOpen,
    setAdminPortalOpen,
    setForgotPasswordOpen,
    switchDemoUser,
    logout
  } = useApp();

  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [editingAvatar, setEditingAvatar] = useState(false);
  const [profileSavedNotice, setProfileSavedNotice] = useState<string | null>(null);

  // In-line Token-based password change simulation
  const [tokenStep, setTokenStep] = useState<'idle' | 'token_sent' | 'success'>('idle');
  const [inputToken, setInputToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [generatedToken, setGeneratedToken] = useState('');
  const [tokenError, setTokenError] = useState('');

  const activeTalents = users
    .filter(u => u.role === 'talent' && u.subscriptionStatus === 'active')
    .sort((a, b) => b.points - a.points);

  const rankPosition = currentUser ? activeTalents.findIndex(t => t.id === currentUser.id) + 1 : 0;

  const handleSelectAvatar = (url: string) => {
    updateCurrentUserProfile({ avatar: url });
    setEditingAvatar(false);
    setProfileSavedNotice('Foto de perfil atualizada com sucesso!');
    setTimeout(() => setProfileSavedNotice(null), 3000);
  };

  const handleSendToken = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedToken(code);
    setTokenStep('token_sent');
    setTokenError('');
  };

  const handleConfirmPasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputToken.trim() !== generatedToken && inputToken.trim() !== '123456') {
      setTokenError('Token de segurança incorreto. Tente novamente.');
      return;
    }
    if (newPassword.length < 8) {
      setTokenError('A nova senha deve ter pelo menos 8 caracteres.');
      return;
    }

    setTokenStep('success');
    setTimeout(() => {
      setTokenStep('idle');
      setInputToken('');
      setNewPassword('');
      setProfileSavedNotice('Senha alterada com sucesso mediante validação de token!');
      setTimeout(() => setProfileSavedNotice(null), 3000);
    }, 2000);
  };

  // If Guest: render rich guest account hub
  if (!currentUser) {
    return (
      <div className="max-w-2xl mx-auto space-y-6 animate-in fade-in">
        <div className="bg-stone-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 text-center space-y-5 shadow-2xl">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-amber-500/10 border-2 border-amber-500/40 flex items-center justify-center text-amber-400 shadow-xl">
            <UserIcon className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Conta de Utilizador • Talent Hub STP
            </h2>
            <p className="text-xs sm:text-sm text-stone-300 max-w-md mx-auto leading-relaxed">
              Você está a navegar no <strong>Modo Convidado</strong>. Pode ver todas as publicações e acompanhar o ranking nacional de São Tomé e Príncipe!
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-stone-950 border border-stone-800 text-left space-y-2.5 text-xs text-stone-300 max-w-lg mx-auto">
            <h4 className="font-bold text-amber-400 flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              Vantagens de Criar Conta no Talent Hub:
            </h4>
            <p className="flex items-center gap-2 text-stone-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Curtir e apoiar os seus artistas preferidos</span>
            </p>
            <p className="flex items-center gap-2 text-stone-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Comentar nas publicações e interagir nos directos (lives)</span>
            </p>
            <p className="flex items-center gap-2 text-stone-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Opção de se tornar TALENT oficial por 50 Dobras/mês</span>
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2 max-w-md mx-auto">
            <button
              onClick={() => {
                setAuthModalInitialTab('register');
                setAuthModalOpen(true);
              }}
              className="flex-1 py-3 px-5 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-600 text-stone-950 font-extrabold text-xs shadow-lg shadow-amber-500/20 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              <span>Criar Nova Conta Gratuita</span>
            </button>

            <button
              onClick={() => {
                setAuthModalInitialTab('login');
                setAuthModalOpen(true);
              }}
              className="flex-1 py-3 px-5 rounded-2xl bg-stone-800 hover:bg-stone-700 text-white font-bold text-xs border border-stone-700 transition-all flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4 text-amber-400" />
              <span>Entrar na Minha Conta</span>
            </button>
          </div>

          {/* Quick Demo Accounts Switcher */}
          <div className="pt-4 border-t border-stone-800">
            <p className="text-[11px] text-stone-400 mb-2 font-semibold">
              Ou experimente alternar diretamente para uma conta de demonstração:
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              <button
                onClick={() => switchDemoUser('user-demo-1')}
                className="px-3 py-1.5 rounded-xl bg-stone-950 border border-stone-800 text-xs text-stone-300 hover:text-amber-400 hover:border-amber-400/50"
              >
                Usuário (Mário)
              </button>
              <button
                onClick={() => switchDemoUser('talent-1')}
                className="px-3 py-1.5 rounded-xl bg-stone-950 border border-amber-500/40 text-xs text-amber-400 font-bold hover:bg-stone-800"
              >
                Talent 1º Gold 🥇 (Kelvin)
              </button>
              <button
                onClick={() => switchDemoUser('admin-1')}
                className="px-3 py-1.5 rounded-xl bg-stone-950 border border-purple-500/40 text-xs text-purple-300 font-bold hover:bg-stone-800"
              >
                Administrador (Gerente)
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Logged in User/Talent Profile Dashboard
  return (
    <div className="max-w-3xl mx-auto space-y-5 animate-in fade-in">
      {profileSavedNotice && (
        <div className="p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{profileSavedNotice}</span>
        </div>
      )}

      {/* Main Profile Header Card */}
      <div className="bg-stone-900 border border-amber-500/30 rounded-3xl p-5 sm:p-7 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
          {/* Avatar with edit button */}
          <div className="relative group">
            <img
              src={currentUser.avatar}
              alt=""
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-4 border-amber-400 shadow-xl"
            />
            <button
              onClick={() => setEditingAvatar(!editingAvatar)}
              className="absolute bottom-0 right-0 p-2 rounded-full bg-stone-950 border border-amber-400 text-amber-400 hover:scale-110 transition-transform shadow-lg"
              title="Mudar Foto de Perfil"
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 text-center sm:text-left space-y-1">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-white">{currentUser.name}</h2>
              {currentUser.role === 'talent' && (
                <span className="text-[10px] bg-amber-500 text-stone-950 font-black px-2 py-0.5 rounded-full uppercase">
                  TALENT OFICIAL
                </span>
              )}
              {currentUser.role === 'admin' && (
                <span className="text-[10px] bg-purple-500 text-white font-bold px-2 py-0.5 rounded-full uppercase">
                  ADMIN ({currentUser.adminLevel})
                </span>
              )}
            </div>

            <p className="text-xs text-amber-400 font-semibold">
              @{currentUser.username} • {currentUser.talentCategory || 'Comunidade STP'}
            </p>

            {currentUser.district && (
              <p className="text-xs text-stone-400 flex items-center justify-center sm:justify-start gap-1 pt-0.5">
                <MapPin className="w-3.5 h-3.5 text-stone-500" />
                <span>{currentUser.district}</span>
              </p>
            )}

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 pt-2 text-xs text-stone-300">
              {currentUser.phone && (
                <span className="flex items-center gap-1">
                  <span>🇸🇹 +239</span>
                  <span>{currentUser.phone}</span>
                </span>
              )}
              {currentUser.email && (
                <span className="flex items-center gap-1 text-stone-400">
                  <Mail className="w-3.5 h-3.5" />
                  <span>{currentUser.email}</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Avatar Selection Drawer when editing */}
        {editingAvatar && (
          <div className="p-4 rounded-2xl bg-stone-950 border border-stone-800 space-y-3 animate-in fade-in">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-white flex items-center gap-2">
                <Camera className="w-4 h-4 text-amber-400" />
                <span>Escolher Nova Foto de Perfil</span>
              </h4>
              <button
                onClick={() => setEditingAvatar(false)}
                className="text-[11px] text-stone-400 hover:text-white"
              >
                Cancelar
              </button>
            </div>

            <p className="text-[11px] text-stone-400">Selecione uma foto pré-definida:</p>
            <div className="flex flex-wrap gap-2.5">
              {AVATAR_CHOICES.map((url, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleSelectAvatar(url)}
                  className="w-12 h-12 rounded-full overflow-hidden border-2 border-stone-700 hover:border-amber-400 transition-all hover:scale-105"
                >
                  <img src={url} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>

            <div className="pt-2 flex gap-2">
              <input
                type="text"
                placeholder="Ou introduza URL de imagem personalizada..."
                value={customAvatarUrl}
                onChange={e => setCustomAvatarUrl(e.target.value)}
                className="flex-1 bg-stone-900 border border-stone-800 rounded-xl px-3 py-1.5 text-xs text-stone-100 focus:outline-none focus:border-amber-400"
              />
              <button
                type="button"
                onClick={() => {
                  if (customAvatarUrl.trim()) handleSelectAvatar(customAvatarUrl.trim());
                }}
                className="px-3 py-1.5 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs"
              >
                Guardar
              </button>
            </div>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="p-3.5 rounded-2xl bg-stone-950 border border-stone-800">
            <span className="text-xs text-stone-400 block">Pontos Totais</span>
            <span className="text-xl sm:text-2xl font-black text-amber-400 font-mono mt-0.5 block">
              {currentUser.points.toLocaleString()}
            </span>
            <span className="text-[10px] text-stone-500">Curtidas recebidas</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-stone-950 border border-stone-800">
            <span className="text-xs text-stone-400 block">Posição no Ranking</span>
            <span className="text-xl sm:text-2xl font-black text-white font-mono mt-0.5 block">
              {rankPosition > 0 ? `#${rankPosition}` : '-'}
            </span>
            <span className="text-[10px] text-stone-500">Top Nacional STP</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-stone-950 border border-stone-800">
            <span className="text-xs text-stone-400 block">Assinatura Mensal</span>
            <span className={`text-xs sm:text-sm font-bold mt-1.5 block ${
              currentUser.subscriptionStatus === 'active' ? 'text-emerald-400' : 'text-amber-400'
            }`}>
              {currentUser.subscriptionStatus === 'active' ? 'Ativa (50 STN)' : 'Inativa / Normal'}
            </span>
            <span className="text-[10px] text-stone-500">Renovação dia 1</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-stone-950 border border-stone-800">
            <span className="text-xs text-stone-400 block">A Seguir</span>
            <span className="text-xl sm:text-2xl font-black text-white font-mono mt-0.5 block">
              {currentUser.followingIds.length}
            </span>
            <span className="text-[10px] text-stone-500">Criadores</span>
          </div>
        </div>

        {/* Subscription Overdue Alert if Blocked (>3 days) */}
        {currentUser.subscriptionStatus === 'blocked' && (
          <div className="p-4 rounded-2xl bg-red-950/60 border border-red-500/40 space-y-2 text-xs text-red-200">
            <div className="flex items-center gap-2 font-bold text-red-300">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <span>Assinatura Bloqueada por Atraso ({currentUser.daysOverdue || 4} dias)</span>
            </div>
            <p>
              Passaram 3 dias sem efetuar o pagamento da renovação da assinatura. O perfil voltou ao estatuto de usuário comum e está temporariamente suspenso do ranking e prémios até regularização.
            </p>
            <button
              onClick={() => setBecomeTalentModalOpen(true)}
              className="px-4 py-2 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs"
            >
              Regularizar Pagamento (50 Dobras)
            </button>
          </div>
        )}

        {/* Primary Action Button */}
        <div className="space-y-2">
          {currentUser.role === 'talent' ? (
            <button
              onClick={() => setTalentStudioOpen(true)}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-600 text-stone-950 font-extrabold text-xs shadow-lg shadow-amber-500/20 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Abrir Estúdio do Talent (Criar Publicação / Live)</span>
            </button>
          ) : (
            <button
              onClick={() => setBecomeTalentModalOpen(true)}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-600 text-stone-950 font-extrabold text-xs shadow-lg shadow-amber-500/20 hover:brightness-110 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <TalentIcon size={16} filled />
              <span>SEJA TALENT (Assinatura de 50 Dobras Mensais)</span>
            </button>
          )}

          {currentUser.role === 'admin' && (
            <button
              onClick={() => setAdminPortalOpen(true)}
              className="w-full py-3 px-4 rounded-2xl bg-purple-950/60 border border-purple-500/40 text-purple-300 font-bold text-xs hover:bg-purple-900/60 transition-colors flex items-center justify-center gap-2"
            >
              <Shield className="w-4 h-4 text-purple-400" />
              <span>Acessar Painel de Administração</span>
            </button>
          )}
        </div>
      </div>

      {/* Security Section: Password Change with OTP Token */}
      <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-7 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <KeyRound className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Segurança & Alteração de Senha</h3>
              <p className="text-[11px] text-stone-400">
                Alteração de senha mediante código token enviado para {currentUser.phone ? `+239 ${currentUser.phone}` : currentUser.email}
              </p>
            </div>
          </div>
        </div>

        {tokenStep === 'idle' && (
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 rounded-2xl bg-stone-950 border border-stone-800">
            <div>
              <p className="text-xs font-semibold text-stone-200">Deseja alterar a sua senha de acesso?</p>
              <p className="text-[11px] text-stone-400">
                Será gerado um token seguro de 6 dígitos enviado para o seu contacto cadastrado.
              </p>
            </div>
            <button
              onClick={handleSendToken}
              className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-amber-300 font-bold text-xs border border-amber-500/30 transition-all shrink-0"
            >
              Gerar Token de Segurança
            </button>
          </div>
        )}

        {tokenStep === 'token_sent' && (
          <form onSubmit={handleConfirmPasswordChange} className="p-4 rounded-2xl bg-stone-950 border border-amber-500/40 space-y-3">
            <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs">
              <span className="font-bold">Token SMS/Email enviado: </span>
              <span className="font-mono font-black text-amber-300 text-sm tracking-widest">{generatedToken}</span>
              <span className="text-[10px] text-stone-400 block mt-0.5">
                (Simulação do código recebido no telemóvel santomense ou email)
              </span>
            </div>

            {tokenError && (
              <p className="text-xs text-red-400">{tokenError}</p>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-stone-400 mb-1">Introduza o Token de 6 Dígitos</label>
                <input
                  type="text"
                  maxLength={6}
                  value={inputToken}
                  onChange={e => setInputToken(e.target.value)}
                  placeholder="Ex: 123456"
                  className="w-full bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 font-mono tracking-widest focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] text-stone-400 mb-1">Nova Senha (Mínimo 8 caracteres)</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 focus:outline-none focus:border-amber-400"
                  required
                />
              </div>
            </div>

            <div className="flex gap-2 justify-end pt-1">
              <button
                type="button"
                onClick={() => setTokenStep('idle')}
                className="px-3 py-1.5 rounded-xl text-xs text-stone-400 hover:text-white"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs hover:bg-amber-400"
              >
                Confirmar e Atualizar Senha
              </button>
            </div>
          </form>
        )}

        {tokenStep === 'success' && (
          <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" />
            <span>Senha atualizada com sucesso! A sua nova credencial está ativa.</span>
          </div>
        )}
      </div>

      {/* Account Switching & Logout Footer */}
      <div className="p-4 rounded-3xl bg-stone-900 border border-stone-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <RefreshCw className="w-4 h-4 text-stone-400" />
          <span className="text-xs text-stone-300 font-semibold">Alternar Conta (Modo Demonstração):</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => switchDemoUser('guest')}
            className="px-2.5 py-1 rounded-lg bg-stone-950 hover:bg-stone-800 text-stone-400 text-xs"
          >
            Convidado
          </button>
          <button
            onClick={() => switchDemoUser('user-demo-1')}
            className="px-2.5 py-1 rounded-lg bg-stone-950 hover:bg-stone-800 text-stone-300 text-xs"
          >
            Usuário
          </button>
          <button
            onClick={() => switchDemoUser('talent-1')}
            className="px-2.5 py-1 rounded-lg bg-stone-950 hover:bg-stone-800 text-amber-400 font-bold text-xs"
          >
            Talent 1º Gold
          </button>
          <button
            onClick={() => switchDemoUser('admin-1')}
            className="px-2.5 py-1 rounded-lg bg-stone-950 hover:bg-stone-800 text-purple-300 font-bold text-xs"
          >
            Admin
          </button>
          <button
            onClick={logout}
            className="px-3 py-1 rounded-lg bg-red-950/50 hover:bg-red-950 text-red-400 text-xs font-bold flex items-center gap-1 border border-red-500/30"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sair</span>
          </button>
        </div>
      </div>
    </div>
  );
};
