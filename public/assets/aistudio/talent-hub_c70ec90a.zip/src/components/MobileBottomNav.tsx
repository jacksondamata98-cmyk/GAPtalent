import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Home,
  Trophy,
  Plus,
  Compass,
  User as UserIcon,
  Sparkles,
  Flame
} from 'lucide-react';
import { TalentIcon } from './TalentIcon';

interface MobileBottomNavProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ currentTab, onSelectTab }) => {
  const {
    currentUser,
    setAuthModalOpen,
    setAuthModalInitialTab,
    setBecomeTalentModalOpen,
    setTalentStudioOpen,
    setGapModalOpen,
    notifications
  } = useApp();

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 lg:hidden">
      {/* Android Material 3 Surface Navigation Bar */}
      <nav className="w-full bg-[#1A1815]/95 backdrop-blur-2xl border-t border-amber-500/20 shadow-[0_-4px_24px_rgba(0,0,0,0.6)] px-2 pt-2 pb-1 flex items-center justify-around select-none">
        {/* 1. Destino: Início (Home) */}
        <button
          type="button"
          onClick={() => onSelectTab('feed')}
          className="flex-1 flex flex-col items-center justify-center py-1 group focus:outline-none"
        >
          {/* Material 3 Active Pill Container */}
          <div
            className={`flex items-center justify-center w-16 h-8 rounded-full transition-all duration-200 ${
              currentTab === 'feed'
                ? 'bg-amber-400 text-stone-950 font-bold shadow-md shadow-amber-500/20 scale-100'
                : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/40'
            }`}
          >
            <Home className="w-5 h-5" />
          </div>
          <span
            className={`text-[11px] font-medium tracking-tight mt-1 transition-colors ${
              currentTab === 'feed' ? 'text-amber-400 font-bold' : 'text-stone-400'
            }`}
          >
            Início
          </span>
        </button>

        {/* 2. Destino: Ranking Top 10 */}
        <button
          type="button"
          onClick={() => onSelectTab('ranking')}
          className="flex-1 flex flex-col items-center justify-center py-1 group focus:outline-none"
        >
          {/* Material 3 Active Pill Container */}
          <div
            className={`flex items-center justify-center w-16 h-8 rounded-full transition-all duration-200 relative ${
              currentTab === 'ranking'
                ? 'bg-amber-400 text-stone-950 font-bold shadow-md shadow-amber-500/20 scale-100'
                : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/40'
            }`}
          >
            <Trophy className="w-5 h-5" />
            <span className="absolute top-1 right-3 w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          </div>
          <span
            className={`text-[11px] font-medium tracking-tight mt-1 transition-colors ${
              currentTab === 'ranking' ? 'text-amber-400 font-bold' : 'text-stone-400'
            }`}
          >
            Ranking
          </span>
        </button>

        {/* 3. Destino Central: SEJA TALENT / CRIAR (Android Floating / Material Pill Style) */}
        <button
          type="button"
          onClick={() => {
            if (currentUser?.role === 'talent') {
              setTalentStudioOpen(true);
            } else {
              setBecomeTalentModalOpen(true);
            }
          }}
          className="flex-1 flex flex-col items-center justify-center py-1 group focus:outline-none"
        >
          {/* Material 3 Highlighted Pill with Gold Shimmer */}
          <div
            className={`flex items-center justify-center w-16 h-8 rounded-full transition-all duration-200 ${
              currentUser?.role === 'talent'
                ? 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-stone-950 font-black shadow-lg shadow-amber-500/30'
                : 'bg-gradient-to-r from-amber-500/25 to-yellow-500/25 border border-amber-400/50 text-amber-300'
            }`}
          >
            {currentUser?.role === 'talent' ? (
              <Plus className="w-5 h-5 stroke-[2.5]" />
            ) : (
              <TalentIcon size={18} filled />
            )}
          </div>
          <span className="text-[11px] font-bold tracking-tight text-amber-300 mt-1 flex items-center gap-0.5">
            {currentUser?.role === 'talent' ? 'Publicar' : 'Talent'}
          </span>
        </button>

        {/* 4. Destino: Serviços GAP (Turismo & Resolve) */}
        <button
          type="button"
          onClick={() => onSelectTab('gap')}
          className="flex-1 flex flex-col items-center justify-center py-1 group focus:outline-none"
        >
          {/* Material 3 Active Pill Container */}
          <div
            className={`flex items-center justify-center w-16 h-8 rounded-full transition-all duration-200 ${
              currentTab === 'gap'
                ? 'bg-amber-400 text-stone-950 font-bold shadow-md shadow-amber-500/20 scale-100'
                : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/40'
            }`}
          >
            <Compass className="w-5 h-5" />
          </div>
          <span
            className={`text-[11px] font-medium tracking-tight mt-1 transition-colors ${
              currentTab === 'gap' ? 'text-amber-400 font-bold' : 'text-stone-400'
            }`}
          >
            GAP
          </span>
        </button>

        {/* 5. Destino: Perfil / Entrar */}
        <button
          type="button"
          onClick={() => onSelectTab('profile')}
          className="flex-1 flex flex-col items-center justify-center py-1 group focus:outline-none"
        >
          {/* Material 3 Active Pill Container */}
          <div
            className={`flex items-center justify-center w-16 h-8 rounded-full transition-all duration-200 ${
              currentTab === 'profile'
                ? 'bg-amber-400 text-stone-950 font-bold shadow-md shadow-amber-500/20 scale-100'
                : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/40'
            }`}
          >
            {currentUser?.avatar ? (
              <img
                src={currentUser.avatar}
                alt=""
                className={`w-5 h-5 rounded-full object-cover ${
                  currentTab === 'profile' ? 'border-2 border-stone-950' : 'border border-amber-400'
                }`}
              />
            ) : (
              <UserIcon className="w-5 h-5" />
            )}
          </div>
          <span
            className={`text-[11px] font-medium tracking-tight mt-1 transition-colors ${
              currentTab === 'profile' ? 'text-amber-400 font-bold' : 'text-stone-400'
            }`}
          >
            {currentUser ? 'Perfil' : 'Entrar'}
          </span>
        </button>
      </nav>

      {/* Android System Gesture Navigation Pill Indicator */}
      <div className="w-full bg-[#1A1815] pb-1.5 flex justify-center items-center">
        <div className="w-28 sm:w-36 h-1 bg-stone-600/70 rounded-full" />
      </div>
    </div>
  );
};
