import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { NotificationCenter } from './NotificationCenter';
import { TalentIcon } from './TalentIcon';
import {
  Bell,
  Sparkles,
  ChevronDown,
  Compass,
  Car,
  Package,
  PlusCircle,
  Radio,
  Shield,
  User as UserIcon,
  LogOut,
  LogIn,
  KeyRound,
  Search,
  Menu,
  X,
  Trophy,
  Target
} from 'lucide-react';

interface HeaderProps {
  currentTab?: string;
  onSelectTab?: (tab: string) => void;
  mobileTab?: string;
  setMobileTab?: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  mobileTab,
  setMobileTab
}) => {
  const {
    currentUser,
    users,
    notifications,
    setAuthModalOpen,
    setAuthModalInitialTab,
    setBecomeTalentModalOpen,
    setTalentStudioOpen,
    setGapModalOpen,
    setGapInitialTab,
    setAdminPortalOpen,
    switchDemoUser,
    logout
  } = useApp();

  const activeNav = currentTab || mobileTab || 'feed';
  const handleNav = (tab: string) => {
    if (onSelectTab) onSelectTab(tab);
    if (setMobileTab) setMobileTab(tab);
  };

  const [notificationOpen, setNotificationOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [gapMenuOpen, setGapMenuOpen] = useState(false);
  const [demoSwitchOpen, setDemoSwitchOpen] = useState(false);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);
  const gapRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter(n => !n.read).length;

  // Close dropdowns on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotificationOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setProfileDropdownOpen(false);
      }
      if (gapRef.current && !gapRef.current.contains(e.target as Node)) {
        setGapMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <>
      <header className="sticky top-0 z-40 w-full bg-stone-950/95 backdrop-blur-xl border-b border-amber-500/20">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 sm:h-18 flex items-center justify-between gap-2 sm:gap-3">
          {/* Logo and Brand */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setMobileDrawerOpen(true)}
              className="lg:hidden p-2 -ml-1 text-stone-300 hover:text-white rounded-xl hover:bg-stone-900 transition-colors"
              aria-label="Abrir menu"
            >
              <Menu className="w-5 h-5 text-amber-400" />
            </button>

            <button
              type="button"
              onClick={() => handleNav('feed')}
              className="flex items-center gap-2 cursor-pointer text-left focus:outline-none"
            >
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-10-01_at_20.13.05-removebg-preview_200ca2a6.png"
                alt="Talent Hub"
                className="h-9 sm:h-11 w-auto object-contain drop-shadow-[0_0_12px_rgba(234,179,8,0.3)] hover:scale-105 transition-transform"
              />
              <div>
                <span className="font-extrabold text-base sm:text-lg tracking-tight bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-500 bg-clip-text text-transparent block leading-tight">
                  Talent hub
                </span>
                <span className="text-[9px] sm:text-[10px] text-stone-400 font-medium tracking-wider uppercase block">
                  São Tomé e Príncipe 🇸🇹
                </span>
              </div>
            </button>
          </div>

          {/* Desktop Center Navigation Items */}
          <nav className="hidden lg:flex items-center gap-1.5 xl:gap-2">
            {/* 1. Início */}
            <button
              onClick={() => handleNav('feed')}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeNav === 'feed'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm shadow-amber-500/20'
                  : 'text-stone-300 hover:text-white hover:bg-stone-900'
              }`}
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span>Início</span>
            </button>

            {/* 2. Ranking Top 10 */}
            <button
              onClick={() => handleNav('ranking')}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeNav === 'ranking'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm shadow-amber-500/20'
                  : 'text-stone-300 hover:text-white hover:bg-stone-900'
              }`}
            >
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>Ranking Top 10</span>
            </button>

            {/* 3. Desafios */}
            <button
              onClick={() => handleNav('challenges')}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeNav === 'challenges'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm shadow-amber-500/20'
                  : 'text-stone-300 hover:text-white hover:bg-stone-900'
              }`}
            >
              <Target className="w-3.5 h-3.5 text-amber-400" />
              <span>Desafios</span>
            </button>

            {/* 4. Submenu com os serviços da empresa GAP */}
            <div className="relative" ref={gapRef}>
              <div className="flex items-center">
                <button
                  onClick={() => handleNav('gap')}
                  className={`px-3 py-2 rounded-l-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeNav === 'gap'
                      ? 'bg-amber-500/20 text-amber-300 border border-r-0 border-amber-500/40'
                      : 'text-stone-300 hover:text-white hover:bg-stone-900 border border-transparent'
                  }`}
                >
                  <Compass className="w-3.5 h-3.5 text-amber-400" />
                  <span>Serviços GAP</span>
                </button>
                <button
                  onClick={() => setGapMenuOpen(!gapMenuOpen)}
                  className={`p-2 rounded-r-xl transition-all border border-l-0 ${
                    activeNav === 'gap'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'text-stone-400 hover:text-white hover:bg-stone-900 border-transparent'
                  }`}
                  title="Mais opções GAP"
                >
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform ${gapMenuOpen ? 'rotate-180' : ''}`} />
                </button>
              </div>

              {gapMenuOpen && (
                <div className="absolute left-0 mt-2 w-72 bg-stone-900/95 backdrop-blur-xl border border-amber-500/30 rounded-2xl shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2 text-xs">
                  <div className="p-2 border-b border-stone-800 text-[11px] text-stone-400 font-semibold flex items-center justify-between">
                    <span>Grupo GAP • São Tomé e Príncipe</span>
                    <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded">STP 🇸🇹</span>
                  </div>

                  <button
                    onClick={() => {
                      setGapInitialTab('turismo');
                      handleNav('gap');
                      setGapMenuOpen(false);
                    }}
                    className="w-full text-left p-2.5 rounded-xl hover:bg-stone-800/80 transition-colors flex items-start gap-2.5"
                  >
                    <Car className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-white block">GAP Serviços & Turismo</span>
                      <span className="text-[11px] text-stone-400 block mt-0.5">
                        Aluguer de Viaturas 4x4 & Roteiros Turísticos em STP
                      </span>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      setGapInitialTab('resolve');
                      handleNav('gap');
                      setGapMenuOpen(false);
                    }}
                    className="w-full text-left p-2.5 rounded-xl hover:bg-stone-800/80 transition-colors flex items-start gap-2.5"
                  >
                    <Package className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-white block">GAP Resolve</span>
                      <span className="text-[11px] text-stone-400 block mt-0.5">
                        Serviços de Delivery, Entregas & Mapa com Localização
                      </span>
                    </div>
                  </button>
                </div>
              )}
            </div>

            {/* 5. Botão SEJA TALENT */}
            <button
              onClick={() => setBecomeTalentModalOpen(true)}
              className="group relative px-3 py-2 rounded-xl bg-gradient-to-r from-amber-500/20 via-yellow-500/30 to-amber-600/20 border border-amber-400/50 hover:border-amber-400 text-stone-100 text-xs font-bold shadow-lg shadow-amber-500/10 hover:shadow-amber-500/25 transition-all flex items-center gap-1.5 ml-1"
            >
              <TalentIcon size={15} filled />
              <span>SEJA TALENT</span>
              <span className="text-[10px] bg-gradient-to-r from-amber-400 to-yellow-500 text-stone-950 font-black px-1.5 py-0.5 rounded-full shadow-sm">
                50 STN
              </span>
            </button>

            {/* If Talent: Studio button */}
            {currentUser?.role === 'talent' && (
              <button
                onClick={() => setTalentStudioOpen(true)}
                className="px-3 py-2 rounded-xl bg-stone-900 border border-amber-400/40 text-amber-300 text-xs font-bold flex items-center gap-1.5 hover:bg-stone-800"
              >
                <PlusCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>Estúdio</span>
              </button>
            )}

            {/* If Admin: Admin Portal button */}
            {currentUser?.role === 'admin' && (
              <button
                onClick={() => setAdminPortalOpen(true)}
                className="px-3 py-2 rounded-xl bg-purple-950/40 border border-purple-500/40 text-purple-300 text-xs font-bold flex items-center gap-1.5 hover:bg-purple-900/40"
              >
                <Shield className="w-3.5 h-3.5 text-purple-400" />
                <span>Admin</span>
              </button>
            )}
          </nav>

          {/* Right Section: Notifications + Auth */}
          <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
            {/* Notification Bell */}
            <div className="relative" ref={notifRef}>
              <button
                onClick={() => setNotificationOpen(!notificationOpen)}
                className="relative p-2 sm:p-2.5 rounded-xl sm:rounded-2xl bg-stone-900 border border-stone-800 hover:border-amber-500/40 text-stone-300 hover:text-white transition-colors"
                title="Notificações"
              >
                <Bell className="w-4 h-4 text-amber-400" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-red-600 text-white text-[9px] sm:text-[10px] font-black flex items-center justify-center animate-pulse border border-stone-950">
                    {unreadCount}
                  </span>
                )}
              </button>

              {notificationOpen && <NotificationCenter onClose={() => setNotificationOpen(false)} />}
            </div>

            {/* Quick Demo Switcher (Desktop) */}
            <div className="relative hidden xl:block">
              <button
                onClick={() => setDemoSwitchOpen(!demoSwitchOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-400 hover:text-amber-300 text-[11px] font-medium"
                title="Alternar perfil para teste"
              >
                <span>Perfil:</span>
                <span className="text-amber-400 font-bold truncate max-w-[85px]">
                  {!currentUser ? 'Convidado' : currentUser.role === 'admin' ? `Admin (${currentUser.adminLevel})` : currentUser.name.split(' ')[0]}
                </span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {demoSwitchOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-stone-900 border border-amber-500/30 rounded-2xl shadow-2xl p-2 z-50 text-xs">
                  <div className="p-2 border-b border-stone-800 text-[10px] text-stone-400 font-bold uppercase tracking-wider">
                    Testar Perfis da Aplicação
                  </div>
                  <button
                    onClick={() => {
                      switchDemoUser('guest');
                      setDemoSwitchOpen(false);
                    }}
                    className={`w-full text-left p-2 rounded-xl flex items-center justify-between ${
                      !currentUser ? 'bg-amber-500/20 text-amber-300 font-bold' : 'hover:bg-stone-800 text-stone-300'
                    }`}
                  >
                    <span>1. Convidado (Sem conta)</span>
                    <span className="text-[10px] text-stone-500">Modo Leitura</span>
                  </button>
                  <button
                    onClick={() => {
                      switchDemoUser('user-demo-1');
                      setDemoSwitchOpen(false);
                    }}
                    className={`w-full text-left p-2 rounded-xl flex items-center justify-between ${
                      currentUser?.id === 'user-demo-1' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'hover:bg-stone-800 text-stone-300'
                    }`}
                  >
                    <span>2. Usuário (Mário da Costa)</span>
                    <span className="text-[10px] text-stone-500">Pode curtir</span>
                  </button>
                  <button
                    onClick={() => {
                      switchDemoUser('talent-1');
                      setDemoSwitchOpen(false);
                    }}
                    className={`w-full text-left p-2 rounded-xl flex items-center justify-between ${
                      currentUser?.id === 'talent-1' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'hover:bg-stone-800 text-stone-300'
                    }`}
                  >
                    <span>3. Talent 1º Gold (Kelvin)</span>
                    <span className="text-[10px] text-amber-400 font-bold">12.480 pts</span>
                  </button>
                  <button
                    onClick={() => {
                      switchDemoUser('admin-1');
                      setDemoSwitchOpen(false);
                    }}
                    className={`w-full text-left p-2 rounded-xl flex items-center justify-between ${
                      currentUser?.role === 'admin' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'hover:bg-stone-800 text-stone-300'
                    }`}
                  >
                    <span>4. Administrador (Gerente)</span>
                    <span className="text-[10px] text-purple-400 font-bold">Acesso Total</span>
                  </button>
                </div>
              )}
            </div>

            {/* If Guest: Persistent button on top right: "Criar conta / entrar" */}
            {!currentUser ? (
              <button
                onClick={() => {
                  setAuthModalInitialTab('register');
                  setAuthModalOpen(true);
                }}
                className="px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-600 text-stone-950 font-extrabold text-xs shadow-md shadow-amber-500/20 hover:brightness-110 active:scale-[0.98] transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <LogIn className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
                <span className="hidden sm:inline">Criar conta / entrar</span>
                <span className="sm:hidden">Entrar / Criar</span>
              </button>
            ) : (
              /* Logged in User Profile Dropdown */
              <div className="relative" ref={profileRef}>
                <button
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  className="flex items-center gap-1.5 sm:gap-2 p-1 pl-1.5 sm:pl-2 bg-stone-900 border border-stone-800 hover:border-amber-500/40 rounded-xl sm:rounded-2xl transition-all"
                >
                  <div className="hidden md:block text-right">
                    <span className="text-xs font-bold text-white block truncate max-w-[100px]">
                      {currentUser.name}
                    </span>
                    <span className="text-[10px] text-amber-400 block font-medium capitalize">
                      {currentUser.role === 'admin' ? `Admin (${currentUser.adminLevel})` : currentUser.role === 'talent' ? `${currentUser.talentCategory}` : 'Usuário'}
                    </span>
                  </div>
                  <img
                    src={currentUser.avatar}
                    alt=""
                    className="w-8 h-8 sm:w-9 sm:h-9 rounded-full object-cover border border-amber-400"
                  />
                  <ChevronDown className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-stone-400 pr-1" />
                </button>

                {profileDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-stone-900/95 backdrop-blur-xl border border-amber-500/30 rounded-2xl shadow-2xl p-2 z-50 text-xs animate-in fade-in">
                    <div className="p-3 border-b border-stone-800">
                      <p className="font-bold text-white text-sm">{currentUser.name}</p>
                      <p className="text-[11px] text-stone-400">@{currentUser.username}</p>
                      <div className="mt-2 flex items-center justify-between text-[11px] bg-stone-950 p-2 rounded-xl">
                        <span className="text-stone-400">Pontos de Talento:</span>
                        <span className="font-mono font-bold text-amber-400">{currentUser.points.toLocaleString()}</span>
                      </div>
                    </div>

                    {currentUser.role === 'talent' && (
                      <button
                        onClick={() => {
                          setTalentStudioOpen(true);
                          setProfileDropdownOpen(false);
                        }}
                        className="w-full text-left p-2.5 rounded-xl hover:bg-stone-800 text-stone-200 flex items-center gap-2 transition-colors"
                      >
                        <PlusCircle className="w-4 h-4 text-amber-400" />
                        <span>Painel do Talent (Publicar / Lives)</span>
                      </button>
                    )}

                    {currentUser.role === 'admin' && (
                      <button
                        onClick={() => {
                          setAdminPortalOpen(true);
                          setProfileDropdownOpen(false);
                        }}
                        className="w-full text-left p-2.5 rounded-xl hover:bg-stone-800 text-purple-300 flex items-center gap-2 transition-colors"
                      >
                        <Shield className="w-4 h-4 text-purple-400" />
                        <span>Painel de Administração</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        logout();
                        setProfileDropdownOpen(false);
                      }}
                      className="w-full text-left p-2.5 rounded-xl hover:bg-red-950/40 text-red-400 flex items-center gap-2 transition-colors mt-1"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sair da Conta (Modo Convidado)</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* MOBILE DRAWER / OFF-CANVAS MENU */}
      {mobileDrawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          {/* Backdrop */}
          <div
            onClick={() => setMobileDrawerOpen(false)}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm animate-in fade-in"
          />

          {/* Drawer Content */}
          <div className="relative w-80 max-w-[85vw] h-full bg-stone-950 border-r border-amber-500/30 p-5 flex flex-col justify-between overflow-y-auto z-10 animate-in slide-in-from-left duration-200 text-stone-100">
            <div className="space-y-4">
              {/* Drawer Header */}
              <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                <div className="flex items-center gap-2">
                  <img
                    src="/assets/aistudio/WhatsApp_Image_2026-10-01_at_20.13.05-removebg-preview_200ca2a6.png"
                    alt=""
                    className="h-9 w-auto object-contain"
                  />
                  <div>
                    <h3 className="font-extrabold text-sm text-white">Talent hub</h3>
                    <p className="text-[10px] text-amber-400">São Tomé e Príncipe 🇸🇹</p>
                  </div>
                </div>
                <button
                  onClick={() => setMobileDrawerOpen(false)}
                  className="p-1.5 rounded-xl bg-stone-900 text-stone-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* User Card inside Drawer */}
              {currentUser ? (
                <div className="p-3 bg-stone-900 rounded-2xl border border-stone-800 space-y-2">
                  <div className="flex items-center gap-3">
                    <img
                      src={currentUser.avatar}
                      alt=""
                      className="w-10 h-10 rounded-full object-cover border border-amber-400"
                    />
                    <div>
                      <h4 className="text-xs font-bold text-white">{currentUser.name}</h4>
                      <p className="text-[11px] text-amber-400">@{currentUser.username}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs pt-1 border-t border-stone-800">
                    <span className="text-stone-400">Pontos:</span>
                    <span className="font-bold text-amber-400">{currentUser.points.toLocaleString()}</span>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-amber-950/20 rounded-2xl border border-amber-500/30 space-y-2">
                  <p className="text-xs font-bold text-white">Modo Convidado</p>
                  <p className="text-[11px] text-stone-400">Crie a sua conta para poder curtir e comentar.</p>
                  <button
                    onClick={() => {
                      setMobileDrawerOpen(false);
                      setAuthModalInitialTab('register');
                      setAuthModalOpen(true);
                    }}
                    className="w-full py-2 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs"
                  >
                    Criar Conta Gratuita
                  </button>
                </div>
              )}

              {/* Main Menu Links */}
              <div className="space-y-1 text-xs">
                {/* Início */}
                <button
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    handleNav('feed');
                  }}
                  className={`w-full text-left p-3 rounded-xl flex items-center gap-2.5 transition-colors ${
                    activeNav === 'feed' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30' : 'hover:bg-stone-900 text-stone-200'
                  }`}
                >
                  <UserIcon className="w-4 h-4 text-amber-400" />
                  <span>Início (Feed de Publicações)</span>
                </button>

                <button
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    setBecomeTalentModalOpen(true);
                  }}
                  className="w-full text-left p-3 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-600/10 border border-amber-500/30 font-bold text-amber-300 flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <TalentIcon size={16} filled />
                    SEJA TALENT
                  </span>
                  <span className="text-[10px] bg-amber-500 text-stone-950 px-2 py-0.5 rounded-full font-black">
                    50 STN
                  </span>
                </button>

                <button
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    handleNav('ranking');
                  }}
                  className={`w-full text-left p-3 rounded-xl flex items-center gap-2.5 transition-colors ${
                    activeNav === 'ranking' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30' : 'hover:bg-stone-900 text-stone-200'
                  }`}
                >
                  <Trophy className="w-4 h-4 text-amber-400" />
                  <span>Ranking Top 10 Nacional</span>
                </button>

                <button
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    handleNav('challenges');
                  }}
                  className={`w-full text-left p-3 rounded-xl flex items-center gap-2.5 transition-colors ${
                    activeNav === 'challenges' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30' : 'hover:bg-stone-900 text-stone-200'
                  }`}
                >
                  <Target className="w-4 h-4 text-amber-400" />
                  <span>Desafios Semanais</span>
                </button>

                <button
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    setGapInitialTab('turismo');
                    handleNav('gap');
                  }}
                  className={`w-full text-left p-3 rounded-xl flex items-center gap-2.5 transition-colors ${
                    activeNav === 'gap' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30' : 'hover:bg-stone-900 text-stone-200'
                  }`}
                >
                  <Car className="w-4 h-4 text-amber-400" />
                  <span>GAP Serviços & Turismo (Viaturas 4x4)</span>
                </button>

                <button
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    setGapInitialTab('resolve');
                    handleNav('gap');
                  }}
                  className={`w-full text-left p-3 rounded-xl flex items-center gap-2.5 transition-colors ${
                    activeNav === 'gap' ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30' : 'hover:bg-stone-900 text-stone-200'
                  }`}
                >
                  <Package className="w-4 h-4 text-emerald-400" />
                  <span>GAP Resolve (Entregas & Mapa STP)</span>
                </button>

                {currentUser?.role === 'talent' && (
                  <button
                    onClick={() => {
                      setMobileDrawerOpen(false);
                      setTalentStudioOpen(true);
                    }}
                    className="w-full text-left p-3 rounded-xl bg-stone-900 text-amber-300 font-bold flex items-center gap-2.5 transition-colors"
                  >
                    <PlusCircle className="w-4 h-4 text-amber-400" />
                    <span>Painel do Talent (Publicar / Live)</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    setAdminPortalOpen(true);
                  }}
                  className="w-full text-left p-3 rounded-xl hover:bg-purple-950/30 text-purple-300 flex items-center gap-2.5 transition-colors"
                >
                  <Shield className="w-4 h-4 text-purple-400" />
                  <span>Painel Administrador (Web)</span>
                </button>
              </div>

              {/* Demo profile switcher in drawer */}
              <div className="pt-2 border-t border-stone-800 space-y-1">
                <p className="text-[10px] text-stone-500 uppercase tracking-wider font-bold px-1">
                  Alternar Conta (Demo)
                </p>
                <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                  <button
                    onClick={() => {
                      switchDemoUser('guest');
                      setMobileDrawerOpen(false);
                    }}
                    className="p-2 rounded-lg bg-stone-900 hover:bg-stone-800 text-left text-stone-300"
                  >
                    Convidado
                  </button>
                  <button
                    onClick={() => {
                      switchDemoUser('user-demo-1');
                      setMobileDrawerOpen(false);
                    }}
                    className="p-2 rounded-lg bg-stone-900 hover:bg-stone-800 text-left text-stone-300"
                  >
                    Usuário
                  </button>
                  <button
                    onClick={() => {
                      switchDemoUser('talent-1');
                      setMobileDrawerOpen(false);
                    }}
                    className="p-2 rounded-lg bg-stone-900 hover:bg-stone-800 text-left text-amber-400 font-bold"
                  >
                    Talent Gold 🥇
                  </button>
                  <button
                    onClick={() => {
                      switchDemoUser('admin-1');
                      setMobileDrawerOpen(false);
                    }}
                    className="p-2 rounded-lg bg-stone-900 hover:bg-stone-800 text-left text-purple-400 font-bold"
                  >
                    Admin
                  </button>
                </div>
              </div>
            </div>

            {/* Drawer Footer */}
            {currentUser && (
              <div className="pt-4 border-t border-stone-800">
                <button
                  onClick={() => {
                    logout();
                    setMobileDrawerOpen(false);
                  }}
                  className="w-full py-2.5 rounded-xl bg-red-950/40 text-red-400 hover:bg-red-950/60 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sair da Conta</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};
