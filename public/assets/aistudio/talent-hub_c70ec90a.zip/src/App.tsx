import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Feed } from './components/Feed';
import { RankingSidebar } from './components/RankingSidebar';
import { ChallengesSection } from './components/ChallengesSection';
import { MobileBottomNav } from './components/MobileBottomNav';
import { AuthModal } from './components/AuthModal';
import { ForgotPasswordModal } from './components/ForgotPasswordModal';
import { BecomeTalentModal } from './components/BecomeTalentModal';
import { TalentStudioModal } from './components/TalentStudioModal';
import { LiveStreamModal } from './components/LiveStreamModal';
import { AdminPortal } from './components/AdminPortal';
import { GapServicesModal } from './components/GapServicesModal';
import { TalentProfileModal } from './components/TalentProfileModal';
import { GuestPromptBanner } from './components/GuestPromptBanner';
import { Newspaper, Trophy, Target, Compass, Sparkles, Plus, Shield, User as UserIcon } from 'lucide-react';
import { ProfileView } from './components/ProfileView';

const MainAppContent: React.FC = () => {
  const {
    currentUser,
    users,
    lives,
    authModalOpen,
    setAuthModalOpen,
    authModalInitialTab,
    becomeTalentModalOpen,
    setBecomeTalentModalOpen,
    talentStudioOpen,
    setTalentStudioOpen,
    activeLive,
    setActiveLive,
    gapModalOpen,
    setGapModalOpen,
    gapInitialTab,
    setGapInitialTab,
    adminPortalOpen,
    setAdminPortalOpen,
    viewingTalentProfile,
    setViewingTalentProfile,
    forgotPasswordOpen,
    setForgotPasswordOpen,
    ads
  } = useApp();

  const [activeTab, setActiveTab] = useState<'feed' | 'ranking' | 'challenges' | 'gap' | 'profile'>('feed');

  const handleTabChange = (tab: string) => {
    setActiveTab(tab as any);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col font-sans selection:bg-amber-500 selection:text-stone-950 pb-28 lg:pb-0">
      {/* Global Header with desktop nav tabs and mobile drawer */}
      <Header
        currentTab={activeTab}
        onSelectTab={handleTabChange}
        mobileTab={activeTab}
        setMobileTab={handleTabChange}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 py-4 sm:py-6">
        {/* VIEW 1: FEED (Início) */}
        {activeTab === 'feed' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-in fade-in">
            {/* Main Feed Column */}
            <div className="lg:col-span-8 space-y-6">
              <Feed
                onOpenLive={liveId => {
                  const live = lives.find(l => l.id === liveId);
                  if (live) setActiveLive(live);
                }}
                onOpenChallenges={() => handleTabChange('challenges')}
              />
            </div>

            {/* Desktop Right Column: Real-Time Ranking & GAP Ads */}
            <div className="hidden lg:block lg:col-span-4 space-y-5">
              <RankingSidebar onOpenChallenges={() => handleTabChange('challenges')} />

              {/* Sponsored Advertisement Card */}
              {ads.length > 0 && ads[0].active && (
                <div
                  onClick={() => {
                    setGapInitialTab('turismo');
                    handleTabChange('gap');
                  }}
                  className="rounded-3xl overflow-hidden border border-amber-500/30 bg-stone-900 cursor-pointer group hover:border-amber-400 transition-all shadow-xl"
                >
                  <div className="relative h-36 overflow-hidden">
                    <img
                      src={ads[0].imageUrl}
                      alt=""
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/30 to-transparent" />
                    <span className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-black/60 text-[9px] text-amber-300 font-bold uppercase tracking-wider">
                      Parceiro Oficial GAP
                    </span>
                    <div className="absolute bottom-2 left-3 right-3">
                      <h4 className="text-xs font-bold text-white drop-shadow">{ads[0].title}</h4>
                      <p className="text-[10px] text-stone-300 drop-shadow line-clamp-1">{ads[0].subtitle}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* VIEW 2: RANKING TOP 10 */}
        {activeTab === 'ranking' && (
          <div className="max-w-4xl mx-auto space-y-5 animate-in fade-in">
            <div className="flex items-center justify-between pb-2 border-b border-stone-800">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-amber-400" />
                  <span>Ranking Oficial dos TALENTS • São Tomé e Príncipe</span>
                </h2>
                <p className="text-xs text-stone-400">
                  Pontuação apurada em tempo real pelas curtidas válidas da comunidade.
                </p>
              </div>

              <button
                onClick={() => handleTabChange('feed')}
                className="text-xs text-stone-400 hover:text-white px-3 py-1.5 rounded-xl bg-stone-900 border border-stone-800"
              >
                Voltar ao Início
              </button>
            </div>

            <RankingSidebar onOpenChallenges={() => handleTabChange('challenges')} />
          </div>
        )}

        {/* VIEW 3: DESAFIOS SEMANAIS */}
        {activeTab === 'challenges' && (
          <div className="max-w-5xl mx-auto space-y-4 animate-in fade-in">
            <ChallengesSection onClose={() => handleTabChange('feed')} />
          </div>
        )}

        {/* VIEW 4: SERVIÇOS GAP (TURISMO & RESOLVE) */}
        {activeTab === 'gap' && (
          <div className="max-w-5xl mx-auto space-y-4 animate-in fade-in">
            <GapServicesModal
              isEmbedded={true}
              initialTab={gapInitialTab}
              onClose={() => handleTabChange('feed')}
            />
          </div>
        )}

        {/* VIEW 5: PERFIL / CONTA */}
        {activeTab === 'profile' && (
          <div className="max-w-3xl mx-auto space-y-4 animate-in fade-in">
            <ProfileView onGoToFeed={() => handleTabChange('feed')} />
          </div>
        )}
      </main>

      {/* Floating Action Button for Talents on Desktop */}
      {currentUser?.role === 'talent' && (
        <button
          onClick={() => setTalentStudioOpen(true)}
          className="hidden lg:flex fixed bottom-6 right-6 z-30 p-4 rounded-full bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-600 text-stone-950 font-black shadow-2xl shadow-amber-500/40 hover:scale-105 active:scale-95 transition-all items-center gap-2"
          title="Criar Publicação ou Iniciar Live"
        >
          <Plus className="w-5 h-5" />
          <span className="text-xs font-bold">Criar / Live</span>
        </button>
      )}

      {/* Mobile Bottom Navigation Bar */}
      <MobileBottomNav currentTab={activeTab} onSelectTab={handleTabChange} />

      {/* Persistent Guest Prompt Banner at bottom (elevated above mobile bottom nav on small screens) */}
      <div className="mb-14 sm:mb-0">
        <GuestPromptBanner />
      </div>

      {/* Footer */}
      <footer className="border-t border-stone-800/80 bg-stone-950 py-8 text-xs text-stone-500 mt-12 mb-12 lg:mb-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => handleTabChange('feed')}
            className="flex items-center gap-2 hover:opacity-80 transition-opacity"
          >
            <img
              src="/assets/aistudio/WhatsApp_Image_2026-10-01_at_20.13.05-removebg-preview_200ca2a6.png"
              alt=""
              className="h-6 w-auto object-contain opacity-80"
            />
            <span className="font-semibold text-stone-300">Talent Hub • São Tomé e Príncipe</span>
          </button>

          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 text-[11px]">
            <button
              onClick={() => handleTabChange('feed')}
              className="hover:text-amber-400 transition-colors"
            >
              Início
            </button>
            <span>•</span>
            <button
              onClick={() => handleTabChange('ranking')}
              className="hover:text-amber-400 transition-colors"
            >
              Ranking Top 10
            </button>
            <span>•</span>
            <button
              onClick={() => handleTabChange('challenges')}
              className="hover:text-amber-400 transition-colors"
            >
              Desafios
            </button>
            <span>•</span>
            <button
              onClick={() => {
                setGapInitialTab('turismo');
                handleTabChange('gap');
              }}
              className="hover:text-amber-400 transition-colors"
            >
              GAP Turismo
            </button>
            <span>•</span>
            <button
              onClick={() => {
                setGapInitialTab('resolve');
                handleTabChange('gap');
              }}
              className="hover:text-amber-400 transition-colors"
            >
              GAP Resolve
            </button>
            <span>•</span>
            <button
              onClick={() => setAdminPortalOpen(true)}
              className="hover:text-amber-400 transition-colors flex items-center gap-1"
            >
              <Shield className="w-3 h-3 text-purple-400" />
              <span>Acesso Administrador</span>
            </button>
          </div>

          <p className="text-[10px] text-center sm:text-right">
            © {new Date().getFullYear()} Talent Hub & Grupo GAP. Todos os direitos reservados.
          </p>
        </div>
      </footer>

      {/* Modals */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialTab={authModalInitialTab}
      />

      <ForgotPasswordModal
        isOpen={forgotPasswordOpen}
        onClose={() => setForgotPasswordOpen(false)}
      />

      <BecomeTalentModal
        isOpen={becomeTalentModalOpen}
        onClose={() => setBecomeTalentModalOpen(false)}
      />

      <TalentStudioModal
        isOpen={talentStudioOpen}
        onClose={() => setTalentStudioOpen(false)}
      />

      <LiveStreamModal
        live={activeLive}
        onClose={() => setActiveLive(null)}
      />

      <AdminPortal
        isOpen={adminPortalOpen}
        onClose={() => setAdminPortalOpen(false)}
      />

      <GapServicesModal
        isOpen={gapModalOpen}
        onClose={() => setGapModalOpen(false)}
        initialTab={gapInitialTab}
      />

      <TalentProfileModal
        talent={viewingTalentProfile}
        onClose={() => setViewingTalentProfile(null)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
